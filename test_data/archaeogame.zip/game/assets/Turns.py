PlayerTurn(self)
nextTurn_button = Button('Next turn', 200, 10, True, self.canvas, self.font)
if pygame.mouse.get_pressed()[0] and new_press:
    new_press = True
    if menu_button.check_click():
        self.SocietyTurn()

if not pygame.mouse.get_pressed()[0] and not new_press:
    new_press = True
print('player turn')

SocietyTurn(self)
nextTurn_button = Button('Next turn', 200, 10, True, self.canvas, self.font)
if pygame.mouse.get_pressed()[0] and new_press:
    new_press = True
    if menu_button.check_click():
        self.EnvironmentTurn()

if not pygame.mouse.get_pressed()[0] and not new_press:
    new_press = True
print("society's turn")

EnvironmentTurn(self)
nextTurn_button = Button('Next turn', 200, 10, True, self.canvas, self.font)
if pygame.mouse.get_pressed()[0] and new_press:
    new_press = True
    if menu_button.check_click():
        continue

if not pygame.mouse.get_pressed()[0] and not new_press:
    new_press = True
print("environment's turn")
