import pygame

#create class for sprite square
class Structure(pygame.sprite.Sprite):
    def __init__(self, image, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image_file = r'C:\Users\aapre\Desktop\code\game\assets\structures\2_cairn.png'
        self.image = pygame.image.load(self.image_file).convert()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)