import pygame
import sys
import os

from button import Button

sys.path.append(r'C:\Users\aapre\Desktop\code/game/tile_map')
from tile_map import CreateMap
sys.path.append(r'C:\Users\aapre\Desktop\code/game/sprites')
from structures import Structure

pygame.init()

width = 800
height = 640
canvas_color = 'white'
canvas = pygame.display.set_mode([width, height])
fps = 60
timer = pygame.time.Clock()
font = pygame.font.SysFont("arialblack", 20)
pygame.display.set_caption('Archaeogaming - a wild ride')

def main_menu():
    run = True
    while run:
        canvas.fill(canvas_color)
        timer.tick(fps)

        game_button = Button('Game', 30, 10, 150, 40, True, canvas, font)
        lore_button = Button('Lore', 30, 70, 150, 40, True, canvas, font)
        options_button = Button('Options', 30, 130, 150, 40, True, canvas, font)
        upload_button = Button('Upload', 30, 190, 150, 40, True, canvas, font)
        quit_button = Button('Quit', 30, 250, 150, 40, True, canvas, font)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if game_button.button_press():
                        #print('game button pressed')
                        CreateMap(timer, fps, canvas, font, canvas_color, width, height)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if lore_button.button_press():
                        print('lore button pressed')
                        lore_book()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if options_button.button_press():
                        print('options button pressed')
                        options_menu()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if upload_button.button_press():
                        print('upload button pressed')
                        upload_menu()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if quit_button.button_press():
                        pygame.quit()
                        sys.exit()

        pygame.display.flip()

    return

def lore_book():
    run = True
    while run:
        canvas.fill(canvas_color)
        timer.tick(fps)

        characters_button = Button('Characters', 30, 10, 150, 40, True, canvas, font)
        buildings_button = Button('Buildings', 30, 70, 150, 40, True, canvas, font)
        geo_button = Button('Geography', 30, 130, 150, 40, True, canvas, font)
        LB_back_button = Button('Back', 30, 190, 150, 40, True, canvas, font)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if characters_button.button_press():
                        print('characters button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if buildings_button.button_press():
                        print('buildings button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if geo_button.button_press():
                        print('geography button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if LB_back_button.button_press():
                        main_menu()

        pygame.display.flip()

    return

def upload_menu():
    run = True
    while run:
        canvas.fill(canvas_color)
        timer.tick(fps)

        ReProp_button = Button('Research', 30, 10, 150, 40, True, canvas, font)
        disclaimer_button = Button('Disclaimer', 30, 70, 150, 40, True, canvas, font)
        consent_button = Button('Consent', 30, 130, 150, 40, True, canvas, font)
        up_back_button = Button('Back', 30, 190, 150, 40, True, canvas, font)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if ReProp_button.button_press():
                        print('research proposal button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if disclaimer_button.button_press():
                        print('disclaimer button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if consent_button.button_press():
                        print('consent button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if up_back_button.button_press():
                        main_menu()

        pygame.display.flip()

    return

def options_menu():
    run = True
    while run:
        canvas.fill(canvas_color)
        timer.tick(fps)

        something_button = Button('something', 30, 10, 150, 40, True, canvas, font)
        another_button = Button('another', 30, 70, 150, 40, True, canvas, font)
        yet_button = Button('another', 30, 130, 150, 40, True, canvas, font)
        OM_back_button = Button('Back', 30, 190, 150, 40, True, canvas, font)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if something_button.button_press():
                        print('something button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if another_button.button_press():
                        print('another button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if another_button.button_press():
                        print('another button pressed')
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # left mouse button?
                    if OM_back_button.button_press():
                        main_menu()

        pygame.display.flip()
        
    return

main_menu()