import pygame
import sys
import os

class Button:
    def __init__(self, text, x_pos, y_pos, wid, hei, enabled, canvas, font):
        self.text = text
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.wid = wid
        self.hei = hei
        self.enabled = enabled
        self.canvas = canvas
        self.btn_color = 'light grey'
        self.button_rect = pygame.rect.Rect( (self.x_pos, self.y_pos), (self.wid, self.hei))
        self.font = font
        self.draw_btn()

    def button_press(self):
        square = pygame.Rect((self.x_pos, self.y_pos), (self.wid, self.hei ))
        pos = pygame.mouse.get_pos()
        if square.collidepoint(pos):
            return True
    
    def draw_btn(self):
        button_text = self.font.render(self.text, True, 'black')
        pygame.draw.rect(self.canvas, self.btn_color, self.button_rect, 0, 5)
        pygame.draw.rect(self.canvas, 'black', self.button_rect, 2, 5)
        self.button_rect = button_text.get_rect(center = self.button_rect.center)
        self.canvas.blit(button_text, self.button_rect)
        return self.button_rect
