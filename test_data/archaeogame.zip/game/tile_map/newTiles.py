import csv, os
import pygame, glob

class ImportMap():
    def __init__(self, csv_filename, canvas, path):
        self.tile_size = 32
        self.start_x, self.start_y = 0, 0
        self.canvas = canvas
        self.path = path
        self.filename = csv_filename
        #self.map_surface = pygame.Surface((self.map_w, self.map_h))
        self.load_tiles()

    def read_csv(self):
        map = []
        with open(os.path.join(self.filename)) as data:
            data = csv.reader(data, delimiter=',')
            for row in data:
                map.append(list(row))
        return map

    def image_import(self):
        self.raster_names = []
        self.csvNums = []
        wildcard_path = "{input_path}\*.png".format(input_path = self.path)
        files = glob.glob(wildcard_path)
        for file in files:
            fileAndExt = os.path.basename(file)
            self.raster_names.append(fileAndExt)

        for name in self.raster_names:
            FileNamePath = os.path.join(self.path, name)
            refNum = name.split("_", 1)
            self.csvNums.append(refNum[0])


    def load_tiles(self):
        
        ocean1Img = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\1_ocean.png')
        ocean2Img = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\2_ocean.png')
        ocean3Img = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\3_ocean.png')
        ocean4Img = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\4_ocean.png')
        forestImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\5_forest.png')
        pineForestImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\6_pineForest.png')
        smallForestImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\7_smallForest.png')
        plainsImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\8_plains.png')
        hillsImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\9_hills.png')
        grasslandsImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\10_grasslands.png')
        grasslandImg = pygame.image.load(r'C:\Users\aapre\Desktop\code\game\assets\tile_images\11_grassland.png')

        self.canvas.fill((0, 0, 0))
        self.image_import()
        print(self.csvNums)
        print(self.raster_names)
        tiles = []
        map = self.read_csv()
        x, y = 0, 0#the loops, and knowing how many pixels bib each tile is, makes geometry easy
        for row in map:
            x = 0
            for tile in row:
                if tile == '0':
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size#needed
                elif tile == self.csvNums[0]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(grasslandsImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[1]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(grasslandImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[2]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(ocean1Img, (self.start_x, self.start_y))
                elif tile == self.csvNums[3]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(ocean2Img, (self.start_x, self.start_y))
                elif tile == self.csvNums[4]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(ocean3Img, (self.start_x, self.start_y))
                elif tile == self.csvNums[5]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(ocean4Img, (self.start_x, self.start_y))
                elif tile == self.csvNums[6]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(forestImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[7]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(pineForestImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[8]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(smallForestImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[9]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(plainsImg, (self.start_x, self.start_y))
                elif tile == self.csvNums[10]:
                    self.start_x, self.start_y = x * self.tile_size, y * self.tile_size
                    self.canvas.blit(hillsImg, (self.start_x, self.start_y))
                    # Move to next tile in current row
                x += 1

            # Move to next row
            y += 1
            # Store the size of the tile map
        self.map_w, self.map_h = x * self.tile_size, y * self.tile_size
        return tiles