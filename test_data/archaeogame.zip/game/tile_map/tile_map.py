import pygame, sys, os, random

from newTiles import *
sys.path.append(r'C:\Users\aapre\Desktop\code/game/GUI')
from button import Button
sys.path.append(r'C:\Users\aapre\Desktop\code/game/sprites')
from structures import Structure

class CreateMap:
    def __init__(self, timer, fps, canvas, font, canvas_color, width, height):
        
        #import newTiles
        #sys.path.append(r'C:\Users\aapre\Desktop\code/game/GUI')
        #from button import Button
        
        self.canvas = canvas
        self.timer = timer
        self.fps = fps
        self.font = font
        self.width = width
        self.height = height
        self.canvas_color = canvas_color
        self.game_loop()

    def turns(self):
        #Player() 
        #SocietyAI()
        #LandscapeAI()
        print('wow next turn')

    def open_main_menu(self):
        from main_game_loop import main_menu# doing this inside the function avoids circular imports
        print('menu')
        main_menu()

    def game_loop(self):

        ImportMap(r'C:\Users\aapre\Desktop\code\game\tile_map\Unst_map.csv', self.canvas, r'C:\Users\aapre\Desktop\code\game\assets\tile_images')

        menu_button = Button('Back', 30, 10, 150, 40, True, self.canvas, self.font)
        nextTurn_button = Button('Next turn', 200, 10, 150, 40, True, self.canvas, self.font)
        build_button = Button('build stuff', 370, 10, 150, 40, True, self.canvas, self.font)

        pygame.display.set_caption('Welcome to the Iron Age')
        #create sprite group for squares
        structure_group = pygame.sprite.Group()

        build = 0
        run = True
        while run:
            self.timer.tick(self.fps)

            #update sprite group
            structure_group.update()

            #draw sprite group
            structure_group.draw(self.canvas)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # left mouse button?
                        if menu_button.button_press():
                            self.open_main_menu()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # left mouse button?
                        if nextTurn_button.button_press():
                            self.turns()

                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:  # left mouse button?
                        if build_button.button_press():
                            build = 1

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and build == 1:  # left mouse button?
                        pos = pygame.mouse.get_pos()
                        #create square and add to the group, white is a placeholder, it places the image nominated in the Structure class
                        structure = Structure('white', pos[0], pos[1])
                        structure_group.add(structure)

            pygame.display.flip()

        pygame.quit()

